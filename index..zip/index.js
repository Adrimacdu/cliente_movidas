'use strict'


let login = document.createElement('div')

login.style.width = '400px'
login.style.height = '400px'
login.style.border = '1px solid black'
login.id = 'form_login'

let form = document.createElement('form')

let inputEmail = document.createElement('input')

inputEmail.id = 'email'
inputEmail.placeholder = 'Introducir email'
inputEmail.type = 'email'
inputEmail.style.width = '250px'
inputEmail.style.margin = '10px auto'
inputEmail.style.padding = '20px'

let labelEmail = document.createElement('label')

labelEmail.for = 'email'
labelEmail.textContent= 'Email'

let inputPassword = document.createElement('input')

inputPassword.id = 'password'
inputPassword.placeholder = 'Introduce contraseña'
inputPassword.type = 'password'
inputPassword.style.width = '250px'
inputPassword.style.margin = '10px auto'
inputPassword.style.padding = '20px'

let labelPassword = document.createElement('label')

labelPassword.for = 'password'
labelPassword.textContent = 'Password'

form.appendChild(labelEmail)
form.appendChild(inputEmail)
form.appendChild(document.createElement('br'))
form.appendChild(labelPassword)
form.appendChild(inputPassword)

form.style.display = 'flex'
form.style.flexDirection = 'column'
form.style.marginTop = '40px'

let button = document.createElement('button')
button.style.padding = '25px'
button.style.width = '180px'
button.style.margin = '20px auto'
button.textContent = 'Log In'



button.addEventListener('click',function(event){

    event.preventDefault()

    let opciones = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            email: inputEmail.value,
            password: inputPassword.value
        })
    }

    fetch('http://localhost:8888/api/auth/jwt/create/', opciones)
    .then(response => {
        if (response.ok) {
            return response.json();
        }
        })
        .then(data => {        
        localStorage.setItem('access_token', data['access']);
        localStorage.setItem('refresh_roken', data['refresh'])
        
        console.log('Inicio de sesión exitoso');
        borrar_login()
        })
        .catch(error => {
        console.error('Error:', error);
        });
        
    })


form.appendChild(button)


login.appendChild(form)

login.style.textAlign ='center'
login.style.margin = 'auto'

document.body.appendChild(login)


/*
const opciones = {
    method:'GET',
    headers:{
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNzA4NDU4NDk0LCJpYXQiOjE3MDg0NTY2OTQsImp0aSI6IjA2YmYwYmUzNDE0MDQ2Y2ZiNTQxNTk2YTk4MDdmOTY1IiwidXNlcl9pZCI6MX0.Fg8BkvIHMQAZ0WN1Dq90-T2WwwcAne_mNvrwic6a2Os'
    }
}
*/


function borrar_login(){
    document.body.removeChild(document.getElementById('form_login'))
    botonera()
}


function botonera(){
    
    let div_botonera = document.createElement('div')

    div_botonera.style.width = '100%'
    div_botonera.style.display = 'flex'
    div_botonera.style.flexDirection = 'row'
    div_botonera.id = 'botonera'

    let boton_modulos = document.createElement('button') 

    boton_modulos.style.margin = 'auto'
    boton_modulos.textContent = 'Modulos'
    boton_modulos.style.padding = '20px'
    boton_modulos.style.width = '30%'

    boton_modulos.addEventListener('click', function(){
        document.body.removeChild(document.getElementById('botonera'))

        let h1 = document.createElement('h1')

        h1.style.textAlign = 'center'
        h1.textContent = 'Modulos'

        document.body.appendChild(h1)

        const opciones = {
            method:'GET',
            headers:{
                'Authorization': 'Bearer ' + localStorage.getItem('access_token')
            }
        }

        fetch('http://localhost:8888/api/modulo_list', opciones)
            .then(response => {
                if (response.ok) {
                    return response.json();
                }
                })
            .then(data => {      
                
                for(let i = 0; i < data.length; i++){

                    let div_modulo = document.createElement('div')
                    
                    div_modulo.textContent = data[i]['__str__']
                    div_modulo.style.width = '90%'
                    div_modulo.style.margin = 'auto'
                    div_modulo.style.height = '20px'
                    div_modulo.style.border = '1px solid black'
                    div_modulo.style.textAlign = 'center'

                    document.body.appendChild(div_modulo)
                }

                })
            .catch(error => {
                console.error('Error:', error);
                });
    })
    

    let boton_ra = document.createElement('button')

    boton_ra.style.margin = 'auto'
    boton_ra.textContent = 'Resultado Aprendizaje'
    boton_ra.style.padding = '20px'
    boton_ra.style.width = '30%'

    boton_ra.addEventListener('click', function(){
        document.body.removeChild(document.getElementById('botonera'))

        let h1 = document.createElement('h1')

        h1.style.textAlign = 'center'
        h1.textContent = 'Resultados de aprendizaje'

        document.body.appendChild(h1)

        const opciones = {
            method:'GET',
            headers:{
                'Authorization': 'Bearer ' + localStorage.getItem('access_token')
            }
        }

        fetch('http://localhost:8888/api/ra_list', opciones)
            .then(response => {
                if (response.ok) {
                    return response.json();
                }
                })
            .then(data => {        
                console.log(data)
                for(let i = 0; i < data.length; i++){

                    let div_ra = document.createElement('div')

                    div_ra.textContent = data[i]['__str__']
                    div_ra.style.width = '90%'
                    div_ra.style.margin = 'auto'
                    div_ra.style.height = '20px'
                    div_ra.style.border = '1px solid black'
                    div_ra.style.textAlign = 'center'

                    document.body.appendChild(div_ra)
                }

                })
            .catch(error => {
                console.error('Error:', error);
                });
    })

    let boton_ce = document.createElement('button')

    boton_ce.style.margin = 'auto'
    boton_ce.textContent = 'Criterio Evaluacion'
    boton_ce.style.padding = '20px'
    boton_ce.style.width = '30%'

    boton_ce.addEventListener('click', function(){
        document.body.removeChild(document.getElementById('botonera'))

        let h1 = document.createElement('h1')

        h1.style.textAlign = 'center'
        h1.textContent = 'Criterio Evaluación'

        document.body.appendChild(h1)

        const opciones = {
            method:'GET',
            headers:{
                'Authorization': 'Bearer ' + localStorage.getItem('access_token')
            }
        }

        fetch('http://localhost:8888/api/ce_list', opciones)
            .then(response => {
                if (response.ok) {
                    return response.json();
                }
                })
            .then(data => {        
                console.log(data)
                for(let i = 0; i < data.length; i++){

                    let div_ra = document.createElement('div')

                    div_ra.textContent = data[i]['__str__']
                    div_ra.style.width = '90%'
                    div_ra.style.margin = 'auto'
                    div_ra.style.height = '20px'
                    div_ra.style.border = '1px solid black'
                    div_ra.style.textAlign = 'center'

                    document.body.appendChild(div_ra)
                }

                })
            .catch(error => {
                console.error('Error:', error);
                });
    })

    div_botonera.appendChild(boton_modulos)
    div_botonera.appendChild(boton_ra)
    div_botonera.appendChild(boton_ce)

    document.body.appendChild(div_botonera) 
}